//monsters.h

// CSCI 1300 Spring 2023
// Authors: Tawhid Ather and Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3

#ifndef Monsters_H
#define Monsters_H
#include <string>
using namespace std;

class Monsters{
    public:
        Monsters();
        string getmonster(int rand_1_to_4);
    
    private:
        const static int monsters_per_floor = 4;
        string monster_names[monsters_per_floor];
        int monster_strength;
        int monsters_stored;
};

#endif