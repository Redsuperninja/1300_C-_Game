//NPC.cpp

// CSCI 1300 Spring 2023
// Author: Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3


#include <iostream>
#include <string>
#include <fstream>
#include "NPC.h"

using namespace std;

NPC :: NPC()
{
    ingredient_price = 1;
    pot_price = 5;
    pan_price = 10;
    cauldron_price = 20;
    club_price = 2;
    spear_price = 2;
    axe_price = 15;
    rapier_price = 5;
    longsword_price = 50;
    armor_price = 5;
    ring_price = 10;  
    necklace_price = 20;  
    bracelet_price = 30;  
    circlet_price = 40;  
    goblet_price = 50;
    vector <string> NPC_dialogue;
}

NPC :: NPC(string filename)
{
    ingredient_price = 1;
    pot_price = 5;
    pan_price = 10;
    cauldron_price = 20;
    club_price = 2;
    spear_price = 2;
    axe_price = 15;
    rapier_price = 5;
    longsword_price = 50;
    armor_price = 5;
    ring_price = 10;  
    necklace_price = 20;  
    bracelet_price = 30;  
    circlet_price = 40;  
    goblet_price = 50;

    vector <string> NPC_dialogue;

    // var to hold the line from file
    string line;
    //opens files stream
    ifstream fin;
    fin.open(filename);

    // if file fails to open end code
    if(fin.fail())
    {
        fin.close();
    }
    else
    {
        // when refrencing line from open file
        while(!fin.eof())
        {
            //retreive line of code from text file
            getline(fin,line);
            NPC_dialogue.push_back(line);   
        }
        //close files
        fin.close();
    }
}

void NPC :: increasePrices(int n ){
    //will incriment al prices based on the intiger input, called from the ststus function getRooms
}

int NPC :: getingredientPrice(){
    return ingredient_price;
}
int NPC :: getPotPrice(){
    return pot_price;
}
int NPC :: getPanPrice(){
    return pan_price;
}
int NPC :: getCauldronPrice(){
    return cauldron_price;
}    
int NPC :: getClubPrice(){
    return club_price;
}
int NPC :: getSpearPrice(){
    return spear_price;
}    
int NPC :: getAxePrice(){
    return axe_price;
}
int NPC :: getRapierPrice(){
    return rapier_price;
}    
int NPC :: getLongswordPrice(){
    return longsword_price;
}
int NPC :: getArmorPrice(){
    return armor_price;
}
int NPC :: getRingPrice(){
    return ring_price;
}
int NPC :: getNecklacePrice(){
    return necklace_price;
}
int NPC :: getBraceletPrice(){
    return bracelet_price;
}
int NPC :: getCircletPrice(){
    return circlet_price;
}
int NPC :: getGobletPrice(){
    return goblet_price;
}