#include "players.h"
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

Players :: Players(string name) {
    player_name = name;
    player_fullness = 100;
    alive = true;
    party_members_alive = 5;
}

/*
    us a random number generate to get a name of a party memeber
    if their is a need to kill a player call this function
    will set the status of the play to dead and decrease the number of party members
*/ 
void Players :: kill_player(string name) {

}

/*
    is a setter to decrease the fullness of a give player
    return the value of the remain fullness
*/
int Players :: lose_fullness(int amount_lost){
}

/*
    equip item of the name and add the strenght to the play class. set that they have an item equip
*/
void Players :: equip_weapon(string name, int strength){

}

/*
    equip armor of the name and add the strenght to the play class. set that they have an item equip
*/
void Players :: equip_armor(string name, int strength){

}

/*
    check if their is armor or weapon equip and if so randomly choose betweent the two and break one
*/
void Players :: break_weapon_or_armor() {

}

/*
    use the monster array and randomly call a monster that exists on the floor
    using the strenth of the parties weapons and armor roll to see if they win the fight
    if they win retrun true if not return false
    if they win remove the monster from the array so it can't be called
    otherwise kill a player afterwards
*/
bool Players :: fight(){

}