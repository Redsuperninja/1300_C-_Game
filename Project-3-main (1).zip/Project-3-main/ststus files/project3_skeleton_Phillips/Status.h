//Status.h

// CSCI 1300 Spring 2023
// Author: Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3 

#ifndef STATUS_H
#define STATUS_H
#include <iostream>

using namespace std;

class Status
{
    private:
    int rooms_cleared;
    int keys;
    int anger;
    int gold;
    int pots;
    int pans;
    int cauldrons;
    int clubs;
    int spears;
    int axes;
    int armor;
    int rings;  //silver ring, referenced with R
    int necklaces;  //ruby necklace, referenced with N
    int bracelets;  //emerald Bracelet, B
    int circlets;  //diamond circlet, C
    int goblets;  //gem-encrusted goblet, G

    public:
    // default constructor
    Status();
    //getter and setter for rooms_cleared
    int getRoomsCleared();
    void setRoomsCleared(int);
    void incrementRooms();
    //getter and setter for keys
    int getKeys();
    void setKeys(int);
    void incrementKeys();
    //getter and setter for anger
    int getAnger();
    void setAnger(int);
    void incrementAnger();
//Inventory Functionality
    //getter and setter for gold
    int getGold();
    void setGold(int);
    void incrementGold();
//Cookware functionality
    //pot opperations
    void setPot(int);
    int usePot();
    int getPot();
    void incrementPot();
    //pan opperations
    void setPan(int);
    int usePan();
    int getPan();
    void incrementPan();
    //Cauldron opperations
    void setCauldron(int);
    int useCauldron();
    int getCauldron();
    void incrementCauldron();
    void printCookware();
//Tresasure functionality
    //getter and setter functions for Rings
    int getRings();
    void setRings(int);
    //getter and setter functions for Necklaces
    int getNecklaces();
    void setNecklaces(int);
    //getter and setter functions for Bracelets
    int getBracelets();
    void setBracelets(int);
    //getter and setter functions for Circlets
    int getCirclets();
    void setCirclets(int);
    //getter and setter functions for Goblets
    int getGoblets();
    void setGoblets(int);
    //print Function
    void printTreasures();

};

#endif