//NPC.cpp

// CSCI 1300 Spring 2023
// Author: Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3


#include <iostream>
#include <string>
#include <fstream>
#include <cassert>
#include "NPC.h"

using namespace std;

int main(){
    //creates default object
    NPC npc;
    assert(npc.getingredientPrice() == 1);
    assert(npc.getPotPrice() == 5);
    assert(npc.getPanPrice() == 10);
    assert(npc.getCauldronPrice() == 20);
    assert(npc.getClubPrice() == 2);
    assert(npc.getSpearPrice() == 2);
    assert(npc.getAxePrice() == 15);
    assert(npc.getRapierPrice() == 5);
    assert(npc.getLongswordPrice() == 50);
    assert(npc.getArmorPrice() == 5);
    assert(npc.getRingPrice() == 10);
    assert(npc.getNecklacePrice() == 20);  
    assert(npc.getBraceletPrice() == 30); 
    assert(npc.getCircletPrice() == 40); 
    assert(npc.getGobletPrice() == 50);  
    //will test void  function when incrimented properly with other functions
    //vector funciton in parameterized funciotn will be tested wiht developted tedt files
    return 0;
}