#include "monsters.h"
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

/*
split a string into parts
1) check if string inputed is none empty
2) loop until you find a delimator/separator
3) store characters into a string until a delimator is found
4) when found store in antoher string in the array
5) return the number of splits found
Parameters: string input_string, char separator, string arr[], int array_size
Retun number of splits
*/
int split(string input_string, char separator, string arr[], int array_size) {
    //initialize number of splits
    int num_splits = 0;
    int string_length = input_string.length();
    string temp = "";
    //check if input string is input and return 0
    if (input_string.length() == 0) {
        return 0;
    }
    //a for loop checking every character in the string
    for (int i = 0; i < string_length; i++) {
        //check if the character is a separator and if not store it in the string array
        if (input_string[i] != separator) {
            temp += input_string[i];
        }
        else {
            arr[num_splits] = temp;
            num_splits++;
            temp = "";
            //if their is not enough space in the array return -1
            if (num_splits > (array_size)){
                return -1;
            }
        }
    }
    //if not delimator found
    if (num_splits == 0) {
        return 1;
    }
    arr[num_splits] = temp;
    //otherwise add one as counting started at 0 rather an 1
    num_splits = num_splits + 1;
    return num_splits;
}

//default constructor
Monsters :: Monsters() {
    //declare a stream for the files
    monsters_stored = 0;
    ifstream fin;
    string postline = "";
    string arr[2];
    //check file opens
    fin.open("monsters.txt");
    while(!fin.eof()) {
        getline(fin, postline);
        split(postline, ',' , arr, 2);
        if(stoi(arr[1]) == monster_strength){
            monster_names[monsters_stored] = arr[0];
            monsters_stored++;
        }
    }   
    fin.close();
}

//get a monster to fight
string Monsters :: getmonster(int rand_0_to_3) {
    string temp;
    temp = monster_names[rand_0_to_3];
    return temp;
}