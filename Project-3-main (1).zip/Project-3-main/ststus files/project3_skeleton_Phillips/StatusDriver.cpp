//StatusDriver.cpp

// CSCI 1300 Spring 2023
// Author: Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3



#include <cstdlib>
#include <iostream>
#include <ctime>
#include <cassert>
#include <string>
#include "Status.h"

using namespace std;

int main()
{
    int srand(time(0));   //will figure out how to make this random with another function intaking time

    //tests that the object is created and defaulted correctly
    Status myStatus;
    assert(myStatus.getRoomsCleared() == 0);
    assert(myStatus.getKeys() == 0);
    assert(myStatus.getAnger() == 0);
    assert(myStatus.getGold() == 100);
    assert(myStatus.getPot() == 0);
        assert(myStatus.usePot() == 0);
    assert(myStatus.getPan() == 0);
        assert(myStatus.usePan() == 0);
    assert(myStatus.getCauldron() == 0);
        assert(myStatus.useCauldron() == 0);
    assert(myStatus.getRings() == 0);
    assert(myStatus.getNecklaces() == 0);
    assert(myStatus.getBracelets() == 0);
    assert(myStatus.getCirclets() == 0);
    assert(myStatus.getGoblets() == 0);

    //tests set and increment function for Rooms cleared
    myStatus.setRoomsCleared(1);
    myStatus.incrementRooms();
    assert(myStatus.getRoomsCleared() == 2);
    //test set and increment function for keys
    myStatus.setKeys(1);
    myStatus.incrementKeys();
    assert(myStatus.getKeys() == 2);
    //test set and increment function for anger
    myStatus.setAnger(1);
    myStatus.incrementAnger();
    assert(myStatus.getAnger() == 2);
    //test set and increment function for Gold
    myStatus.setGold(0);
    myStatus.incrementGold();
    assert(myStatus.getGold() == 1);
    //test set and increment function for pots
    myStatus.setPot(1);
    myStatus.incrementPot();
    //test usePot function to check that 1/4 of the fime it will break and return false will be incrimented later
    assert(myStatus.getPot() == 2);
    //test set and increment function for pans
    myStatus.setPan(1);
    myStatus.incrementPan();
    assert(myStatus.getPan() == 2);
    myStatus.usePot();
    //test usePan function to check that 1/10 of the fime it will break and return false
    //test set and increment function for Cauldron
    myStatus.setCauldron(1);
    myStatus.incrementCauldron();
    assert(myStatus.getCauldron() == 2);
    //test useCauldron function to check that 1/50 of the fime it will break and return false
    //test set and increment function for Rings
    myStatus.setRings(1);
    assert(myStatus.getRings() == 1);
    myStatus.setNecklaces(1);
    assert(myStatus.getNecklaces() == 1);
    myStatus.setBracelets(1);
    assert(myStatus.getBracelets() == 1);
    myStatus.setCirclets(1);
    assert(myStatus.getCirclets() == 1);
    myStatus.setGoblets(1);
    assert(myStatus.getGoblets() == 1);

    //tests void print function expected output: P: 2 | F: 2 | C: 2
    myStatus.printCookware();
    //tests voit print treasures function expected output: R: 1 | N: 1 | B: 1 | C: 1 | G: 1
    myStatus.printTreasures();

    return 0;
}