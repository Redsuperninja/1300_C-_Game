#ifndef PLAYERS_H
#define PLAYERS_H
#include <string>
#include "monsters.h"
using namespace std;

class Players{
    public:
        Players(string name);
        void kill_player(string name);
        int lose_fullness(int amount_lost);
        void equip_weapon(string name, int strength);
        void equip_armor(string name, int strength);
        void break_weapon_or_armor();
        bool fight();
        
    private:
        string player_name;
        int player_fullness;
        int party_members_alive;
        bool alive;
        bool armor_equip;
        string armor_name;
        int armor_strength;
        bool weapon_equip;
        string weapon_name;
        int weapon_strengh;
        Monsters monsters[];

};
#endif