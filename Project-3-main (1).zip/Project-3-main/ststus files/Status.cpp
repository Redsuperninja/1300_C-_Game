//Status.cpp

// CSCI 1300 Spring 2023
// Author: Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3

//int srand(time(0));

#include <iostream>
#include <string>
#include "Status.h"

using namespace std;

Status :: Status()
{
    rooms_cleared = 0;
    keys = 0;
    anger = 0;
    gold = 100;
    ingredients = 0;
    pots = 0;
    pans = 0;
    cauldrons = 0;
    clubs = 0;
    spears = 0;
    rapier = 0;
    axes = 0;
    longsword = 0;
    armor = 0;
    rings = 0;  //silver ring, referenced with R
    necklaces = 0;  //ruby necklace, referenced with N
    bracelets = 0;  //emerald Bracelet, B
    circlets = 0;  //diamond circlet, C
    goblets = 0;
}
//getter and setter for rooms_cleared
int Status :: getRoomsCleared(){
    return rooms_cleared;
}
void Status :: setRoomsCleared(int n){
    rooms_cleared = n;
}
void Status :: incrementRooms(){
    rooms_cleared++;
}
//getter and setter for keys
int Status :: getKeys(){
    return keys;
}
void Status :: setKeys(int k){
    keys = k;
}
void Status :: incrementKeys(){
    keys++;
}
//getter and setter for anger
void Status :: setAnger(int a){
    anger = a;
}
int Status :: getAnger(){
    return anger;
}
void Status :: incrementAnger(){
    anger++;
}
//getter and setter for gold
int Status :: getGold(){
    return gold;
}
void Status :: setGold(int g){
    gold = g;
}
void Status :: incrementGold(int g){
    gold+= g;
}
//Weapon Funcitonality
void Status :: incrementClub(int c){
    clubs += c;
}
int Status :: getClub(){
    return clubs;
}
void Status ::incrementRapier(int r){
    rapier += r;
}
int Status :: getRapier(){
    return rapier;
}
void Status ::incrementSpears(int s){
    spears += s;
}
int Status :: getSpear(){
    return spears;
}
void Status ::incrementLongsword(int l){
    longsword += l;
}
int Status :: getLongsword(){
    return longsword;
}
void Status ::incrementAxe(int a){
    axes += a;
}
int Status :: getAxe(){
    return axes;
}
void Status ::incrementArmor(int a){
    axes += a;
}
int Status :: getArmor(){
    return armor;
}

//getter and setter for ingredients
int Status :: getIngredients(){
    return ingredients;
}
void Status :: setIngredients(int i){
    ingredients = i;
}
void Status :: incrementIngredients(int i){
    ingredients += i;
}

//pot opperations
void Status :: setPot(int p){
    pots = p;
}
int Status :: getPot()
{
    return pots;
}
void Status :: incrementPot(){
    pots++;
}
int Status :: usePot()
{
    if(pots == 0){
        //cout << "You have no pots to cook with silly." << endl;
        return 0;
    }
    int random = (rand() % 4);
    cout << random << endl;
    if(random == 1){
        pots -= 1;
        //cout << "Your pot broke you! You now have " << pots << " pots." << endl;
        return -1;   //will be changed to -1 when a test that the proper intigers are found
    }
    return 1;    //returns true if cookware was used and is still in invintory
}
//pan opperations
void Status :: setPan(int pan){
    pans = pan;
}
int Status :: getPan()
{
    return pans;
}
void Status :: incrementPan(){
    pans++;
}
int Status :: usePan()
{
    if(pans == 0){
        //cout << "You have no pans to cook with silly." << endl;
        return 0;   //returns
    }
    int random = (rand() % 10);
    if(random == 1){
        pans -= 1;
        //cout << "Your pan broke you! You now have " << pans << " pans." << endl;
        return -1;  //return -1 if breaks
    }
    return 1;    //returns 1 if cookware was used and is still in invintory
}
//Cauldron opperations
void Status :: setCauldron(int c){
    cauldrons = c;
}
int Status :: getCauldron()
{
    return cauldrons;
}
int Status :: useCauldron()
{
    if(cauldrons == 0){
        //cout << "You have no cauldrons to cook with silly." << endl;
        return 0;   //returns 0 if not ran
    }
    int random = (rand() % 50);
    if(random == 1){
        cauldrons -= 1;
        //cout << "Your cauldron broke you! You now have " << cauldrons << " cauldrons." << endl;
        return -1;  //returns -1 if item breaks
    }
    return 1;    //returns 1 if cookware was used and is still in invintory
}
void Status :: incrementCauldron(){
    cauldrons++;
}
//print cookware
void Status :: printCookware()
{
    cout << "P: " << pots << " | F: " << pans << " | C: " << cauldrons << endl;
}
//getter and setter functions for Rings
int Status :: getRings(){
    return rings;
}
void Status :: setRings(int ring){
    rings = ring;
}
//getter and setter functions for Necklaces
int Status :: getNecklaces(){
    return necklaces;
}
void Status :: setNecklaces(int neck){
    necklaces = neck;
}
//getter and setter functions for Bracelets
int Status :: getBracelets(){
    return bracelets;
}
void Status :: setBracelets(int brace){
    bracelets = brace;
}
//getter and setter functions for Circlets
int Status :: getCirclets(){
    return circlets;
}
void Status :: setCirclets(int circle){
    circlets = circle;
}
//getter and setter functions for Goblets
int Status :: getGoblets(){
    return goblets;
}
void Status :: setGoblets(int gobble){
    goblets = gobble;
}
//print treasures 
void Status :: printTreasures()
{
    cout << "R: " << rings << " | N: " << necklaces << " | B: " << bracelets << " | C: " << circlets << " | G: " << goblets << endl;
}