#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include<cstdlib>
#include<ctime>
#include<cmath>

#include "Map.h"
#include "monsters.h"

using namespace std;

int main() {
    srand((unsigned int)time(0));
    Map map;
    cout << "Initial map: " << endl;
    //set rooms
    while(map.getRoomCount() != 5) {
        map.addRoom((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    }
    while(map.getNPCCount() != 3) {
        map.addNPC((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    }
    map.displayMap();
    return 0;
}