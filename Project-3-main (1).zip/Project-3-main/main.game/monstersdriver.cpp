#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include<cstdlib>
#include<ctime>
#include<cmath>

#include "Map.h"
#include "monsters.h"
#include "status.h"
#include "players.h"

int main() {
    srand((unsigned int)time(0));
    Monsters m(1);
    string temp1 = m.getmonster((double(rand() / double(RAND_MAX)) * m.get_number_of_monsters()));
    
    cout << temp1 << endl;
}