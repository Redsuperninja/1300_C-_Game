#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include<cstdlib>
#include<ctime>
#include<cmath>

#include "Map.h"
#include "monsters.h"
#include "status.h"
#include "players.h"

using namespace std;

int main() {
    srand((unsigned int)time(0));
    Status status;
    Map map;
    Monsters monsters(1);
    string monster_name;
    int action_choice = 0;
    char player_move = ' ';
    bool game_over = false;
    bool game_win = false;
    map.setPlayerPosition((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    map.setDungeonExit((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    //set rooms
    while(map.getRoomCount() != 5) {
        map.addRoom((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    }
    while(map.getNPCCount() != 5) {
        map.addNPC((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    }
    status.setpartymembers();
    while (!game_over || !game_win) {
        status.printstatus();
        map.displayMap();
        //if the player is on the dungeon exit
        if (map.isDungeonExit(map.getPlayerRow(), map.getPlayerCol())) {
            if(map.getRoomCount() == 0) {
                cout << "You have vanquished the sorcerer and reach the exit!" << endl;
                game_win = true;
            }
            else{
                cout << "You can't exit the dungeon yet! Continue to explore the duegon and vanish the sorcer to unlock the exit." << endl;
                cout << "Select a direction to move" << endl;
                cin >> player_move;
                while(map.move(player_move) == false) {
                    cout << "Please enter a valid direction" << endl;
                    cin >> player_move;
                }
            }
        }
        //if the player has entered a room
        else if(map.isRoomLocation(map.getPlayerRow(), map.getPlayerCol())) {
            cout << "You have encounter an NPC! What would you like to do?" << endl;
            cout <<  "Select one:" << endl;
            cout << "1. Move" << endl;
            cout << "2. Open the Door"  << endl;
            cout << "3. Give up" << endl;
            cin >> action_choice;
            switch(action_choice) {
                case 1:
                    cout << "Select a direction to move" << endl;
                    cin >> player_move;
                    while(map.move(player_move) == false) {
                        cout << "Please enter a valid direction" << endl;
                        cin >> player_move;
                    }
                    break;
                case 2:
                    break;
                case 3:
                    cout << "The party has given up." << endl;
                    game_over = true;
                    break;
                default:
                    cout << "Please choose a valid action" << endl;
                    while(action_choice < 1 || action_choice > 3) {
                        cout <<  "Select one:" << endl;
                        cout << "1. Move" << endl;
                        cout << "2. Speak to NPC"  << endl;
                        cout << "3. Give up" << endl;
                        cin >> action_choice;
                    }
                    break;
            }
        }
        //if the player has meet an NPC
        else if(map.isNPCLocation(map.getPlayerRow(), map.getPlayerCol())) {
            cout << "You have encounter an NPC! What would you like to do?" << endl;
            cout <<  "Select one:" << endl;
            cout << "1. Move" << endl;
            cout << "2. Speak to NPC"  << endl;
            cout << "3. Give up" << endl;
            cin >> action_choice;
            switch(action_choice) {
                case 1:
                    cout << "Select a direction to move" << endl;
                    cin >> player_move;
                    while(map.move(player_move) == false) {
                        cout << "Please enter a valid direction" << endl;
                        cin >> player_move;
                    }
                    break;
                case 2:
                    break;
                case 3:
                    cout << "The party has given up." << endl;
                    game_over = true;
                    break;
                default:
                    cout << "Please choose a valid action" << endl;
                    while(action_choice < 1 || action_choice > 3) {
                        cout <<  "Select one:" << endl;
                        cout << "1. Move" << endl;
                        cout << "2. Speak to NPC"  << endl;
                        cout << "3. Give up" << endl;
                        cin >> action_choice;
                    }
                    break;
            }
        }
        else { 
            cout <<  "Select one:" << endl;
            cout << "1. Move" << endl;
            cout << "2. Investigate"  << endl;
            cout << "3. Pick a Fight" << endl;
            cout << "4. Cook and Eat" << endl;
            cout << "5. Give up" << endl;
            cin >> action_choice;
            switch(action_choice) {
                case 1:
                    cout << "Select a direction to move" << endl;
                    cin >> player_move;
                    while(map.move(player_move) == false) {
                        cout << "Please enter a valid direction" << endl;
                        cin >> player_move;
                    }
                    break;
                case 2:
                    break;
                case 3:
                    cout << "You decide to go looking for a fight. Lets see what you find." << endl;
                    monster_name = monsters.getmonster((double(rand() / double(RAND_MAX)) * monsters.get_number_of_monsters()));
                    cout << monster_name << "AHEAD! THEY LOOK HOSTILE!" << endl;
                    if(status.getnumberweapons() >= 1) {
                        cout << "Choose if you want to fight or surrender" << endl;
                        cout << "1. Attack" << endl;
                        cout << "2. Surrender"  << endl;
                        cin >> action_choice;
                    }
                    else{
                        cout << "You have no weapons you must surrender" << endl;
                    }
                    break;
                case 4:
                    break;
                case 5:
                    cout << "The party has given up." << endl;
                    game_over = true;
                    break;
                default:
                    cout << "Please choose a valid action" << endl;
                    while(action_choice < 1 || action_choice > 5) {
                        cout <<  "Select one:" << endl;
                        cout << "1. Move" << endl;
                        cout << "2. Investigate"  << endl;
                        cout << "3. Pick a Fight" << endl;
                        cout << "4. Cook and Eat" << endl;
                        cout << "5. Give up" << endl;
                        cin >> action_choice;
                    }  
                    break;
            }
        }
    }
    return 0;
}