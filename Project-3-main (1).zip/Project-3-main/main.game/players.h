#ifndef PLAYERS_H
#define PLAYERS_H
#include <string>
#include "monsters.h"
using namespace std;

class Players{
    public:
        Players(string name);
        string getplayername();
        int getfullness();
        int lose_fullness(int amount_lost);
        
    private:
        string player_name;
        int player_fullness;

};

#endif