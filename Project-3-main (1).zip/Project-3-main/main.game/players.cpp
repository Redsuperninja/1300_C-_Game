#include "players.h"
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

Players :: Players(string name) {
    player_name = name;
    player_fullness = 50;
}

string Players :: getplayername() {
    return player_name;
}

int Players :: getfullness() {
    return player_fullness;
}

/*
    is a setter to decrease the fullness of a give player
    return the value of the remain fullness
*/
int Players :: lose_fullness(int amount_lost){
    return player_fullness -= amount_lost;
}

/*
    use the monster array and randomly call a monster that exists on the floor
    using the strenth of the parties weapons and armor roll to see if they win the fight
    if they win retrun true if not return false
    if they win remove the monster from the array so it can't be called
    otherwise kill a player afterwards
*/