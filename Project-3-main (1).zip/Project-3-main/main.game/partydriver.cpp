#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include<cstdlib>
#include<ctime>
#include<cmath>

#include "Map.h"
#include "monsters.h"
#include "players.h"

int main() {
    vector<Players> party;
    string player_names;
    cout << "Enter your name: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
    cout << "Enter the name of your first party member: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
    cout << "Enter the name of your second party member: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
    cout << "Enter the name of your third party member: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
    cout << "Enter the name of your fourth and final party member: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
}