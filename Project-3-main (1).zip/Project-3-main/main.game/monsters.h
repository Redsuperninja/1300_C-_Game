//monsters.h

// CSCI 1300 Spring 2023
// Authors: Tawhid Ather and Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3

#ifndef Monsters_H
#define Monsters_H
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

class Monsters{
    public:
        Monsters(int difficulty);
        string getmonster(int rand);
        int get_number_of_monsters();
        void monster_killed(string monster_name);
        bool fight_monster();
    private:
        vector<string> monster_names;
        int monster_strength;
        int number_of_monsters;
};

#endif