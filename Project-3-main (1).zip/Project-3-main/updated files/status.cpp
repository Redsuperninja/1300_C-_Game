//Status.cpp

// CSCI 1300 Spring 2023
// Author: Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3

//int srand(time(0));

#include <iostream>
#include <string>
#include "status.h"

using namespace std;

Status :: Status()
{
    rooms_cleared = 0;
    keys = 0;
    anger = 0;
    gold = 100;
    ingredients = 0;
    pots = 0;
    pans = 0;
    cauldrons = 0;
    clubs = 0;
    spears = 0;
    rapier = 0;
    axes = 0;
    longsword = 0;
    armor = 0;
    rings = 0;  //silver ring, referenced with R
    necklaces = 0;  //ruby necklace, referenced with N
    bracelets = 0;  //emerald Bracelet, B
    circlets = 0;  //diamond circlet, C
    goblets = 0;
}
//getter and setter for rooms_cleared
int Status :: getRoomsCleared(){
    return rooms_cleared;
}
void Status :: setRoomsCleared(int n){
    rooms_cleared = n;
}
void Status :: incrementRooms(){
    rooms_cleared++;
}
//getter and setter for keys
int Status :: getKeys(){
    return keys;
}
void Status :: setKeys(int k){
    keys = k;
}
void Status :: incrementKeys(){
    keys++;
}
//getter and setter for anger
void Status :: setAnger(int a){
    anger = a;
}
int Status :: getAnger(){
    return anger;
}
void Status :: incrementAnger(){
    anger++;
}
//getter and setter for gold
int Status :: getGold(){
    return gold;
}
void Status :: setGold(int g){
    gold = g;
}
void Status :: incrementGold(int g){
    gold+= g;
}
//Weapon Funcitonality
void Status :: incrementClub(int c){
    clubs += c;
}
int Status :: getClub(){
    return clubs;
}
void Status ::incrementRapier(int r){
    rapier += r;
}
int Status :: getRapier(){
    return rapier;
}
void Status ::incrementSpears(int s){
    spears += s;
}
int Status :: getSpear(){
    return spears;
}
void Status ::incrementLongsword(int l){
    longsword += l;
}
int Status :: getLongsword(){
    return longsword;
}
void Status ::incrementAxe(int a){
    axes += a;
}
int Status :: getAxe(){
    return axes;
}
void Status ::incrementArmor(int a){
    axes += a;
}
int Status :: getArmor(){
    return armor;
}

//getter and setter for ingredients
int Status :: getIngredients(){
    return ingredients;
}
void Status :: setIngredients(int i){
    ingredients = i;
}
void Status :: incrementIngredients(int i){
    ingredients += i;
}

//pot opperations
void Status :: setPot(int p){
    pots = p;
}
int Status :: getPot()
{
    return pots;
}
void Status :: incrementPot(){
    pots++;
}
int Status :: usePot()
{
    if(pots == 0){
        cout << "You have no pots to cook with silly." << endl;
        return 0;
    }
    int random = (rand() % 4);
    cout << random << endl;
    if(random == 1){
        pots -= 1;
        cout << "Your pot broke you! You now have " << pots << " pots." << endl;
        return -1;   //will be changed to -1 when a test that the proper intigers are found
    }
    return 1;    //returns true if cookware was used and is still in invintory
}
//pan opperations
void Status :: setPan(int pan){
    pans = pan;
}
int Status :: getPan()
{
    return pans;
}
void Status :: incrementPan(){
    pans++;
}
int Status :: usePan()
{
    if(pans == 0){
        cout << "You have no pans to cook with silly." << endl;
        return 0;   //returns
    }
    int random = (rand() % 10);
    if(random == 1){
        pans -= 1;
        cout << "Your pan broke you! You now have " << pans << " pans." << endl;
        return -1;  //return -1 if breaks
    }
    return 1;    //returns 1 if cookware was used and is still in invintory
}
//Cauldron opperations
void Status :: setCauldron(int c){
    cauldrons = c;
}
int Status :: getCauldron()
{
    return cauldrons;
}
int Status :: useCauldron()
{
    if(cauldrons == 0){
        cout << "You have no cauldrons to cook with silly." << endl;
        return 0;   //returns 0 if not ran
    }
    int random = (rand() % 50);
    if(random == 1){
        cauldrons -= 1;
        cout << "Your cauldron broke you! You now have " << cauldrons << " cauldrons." << endl;
        return -1;  //returns -1 if item breaks
    }
    return 1;    //returns 1 if cookware was used and is still in invintory
}
void Status :: incrementCauldron(){
    cauldrons++;
}
//print cookware
void Status :: printCookware()
{
    cout << "P: " << pots << " | F: " << pans << " | C: " << cauldrons << endl;
}
//getter and setter functions for Rings
int Status :: getRings(){
    return rings;
}
void Status :: setRings(int ring){
    rings = ring;
}
//getter and setter functions for Necklaces
int Status :: getNecklaces(){
    return necklaces;
}
void Status :: setNecklaces(int neck){
    necklaces = neck;
}
//getter and setter functions for Bracelets
int Status :: getBracelets(){
    return bracelets;
}
void Status :: setBracelets(int brace){
    bracelets = brace;
}
//getter and setter functions for Circlets
int Status :: getCirclets(){
    return circlets;
}
void Status :: setCirclets(int circle){
    circlets = circle;
}
//getter and setter functions for Goblets
int Status :: getGoblets(){
    return goblets;
}
void Status :: setGoblets(int gobble){
    goblets = gobble;
}
//print treasures 
void Status :: printTreasures()
{
    cout << "R: " << rings << " | N: " << necklaces << " | B: " << bracelets << " | C: " << circlets << " | G: " << goblets << endl;
}

//print status
void Status :: printstatus() {
    cout << "+-------------+" << endl;
    cout << "| STATUS      |" << endl;
    cout << "+-------------+" << endl;
    cout << "|  Rooms Cleared: " << rooms_cleared << " | Keys: " << keys << " | Anger Level: " << anger << endl;
    cout << "+-------------+" << endl;
    cout << "| INVENTORY   |" << endl;
    cout << "+-------------+" << endl;
    cout << "| Gold        | " << gold << endl;
    cout << "| Ingredients | " << ingredients << "kg" << endl;
    cout << "| Cookware    | P: " << pots << " | F: " << pans << " | C: " << cauldrons << endl;
    cout << "| Weapons     | C: " << clubs << " | S: " << spears << " | R: " << rapier << " | B: " << axes << " | L: " << longsword << endl;
    cout << "| Armor       | " << armor << endl;
    cout << "| Treasures   | R: " << rings << " | N: " << necklaces << " | B: " << bracelets << " | C: " << circlets << " | G: " << goblets << endl;
    cout << "+-------------+" << endl;
    cout << "| PARTY       |" << endl;
    cout << "+-------------+" << endl;
    cout << "| " << party.at(0).getplayername() << " | Fullness: " << party.at(0).getfullness() << endl;
    cout << "| " << party.at(1).getplayername() << " | Fullness: " << party.at(1).getfullness() << endl;
    cout << "| " << party.at(2).getplayername() << " | Fullness: " << party.at(2).getfullness() << endl;
    cout << "| " << party.at(3).getplayername() << " | Fullness: " << party.at(3).getfullness() << endl;
    cout << "| " << party.at(4).getplayername() << " | Fullness: " << party.at(4).getfullness() << endl;
}

void Status :: setpartymembers() {
    string player_names = "";
    cout << "Enter your name: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
    cout << "Enter the name of your first party member: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
    cout << "Enter the name of your second party member: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
    cout << "Enter the name of your third party member: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
    cout << "Enter the name of your fourth and final party member: " << endl;
    cin >> player_names;
    party.push_back(Players(player_names));
}

int Status :: getnumberweapons() {
    return clubs + rapier + spears + longsword + axes;
}

void Status :: merchantMenu(NPC myMerchant)
{
    int menu = 0;
    int choice = 0;
    int num = 0;
    char yeno;
    char treasure;


    while(menu != 6){
        while(menu < 1 || menu > 6){
            cout << "\n+-------------+\n| INVENTORY   |\n+-------------+\n| Gold        | " << gold << "\n| Ingredients | " << ingredients << " kg \n| Cookware    | P: " << pots << " | F: " << pans << " | C: " << cauldrons << endl;
            cout << "| Weapons     | C: " << clubs << " | S: " << spears << " | R: " << rapier << " | B: " << axes << " | L: " << longsword << "\n| Armor       | " << armor << "\n| Treasures   | R: " << rings << " | N: " << necklaces << " | B: " << bracelets << " | C: " << circlets << " | G: " << goblets << "" << endl;
            cout <<"\nChoose one of the following: \n1. Ingredients: To make food, you have to cook raw ingredients. \n2. Cookware: You will need something to cook those ingredients. \n3. Weapons: It's dangerous to go alone, take this!" << endl;
            cout << "4. Armor: If you want to survive monster attacks, you will need some armor. \n5. Sell treasures: If you find anything shiny, I would be happy to take it off your hands. \n6. Leave: Make sure you get everything you need, I'm leaving after this sale!" << endl;
            cin >> menu;
            if(menu < 1 || menu > 6){
                cout << "Invalid input. Please enter a number between 1 and 6." << endl;
                menu = 0; }
            cout << endl;
        }
        switch(menu){
        case 1: 
            cout << "I would recomend 10 kg of food per party member for your voyage!" << endl;
            cout << "How many kg of ingredients do you need [" << myMerchant.getingredientPrice() << " Gold/kg]? (Enter a positive mulitple of 5, or 0 to cancel)" << endl;
            cin >> num;
            if(num % 5 != 0){
                cout << "Invalid input." << endl;
                menu = 1;
                break; }    
            while(num != 0){
                cout << "You want to buy " << num << " kg of ingredients for "<< num * myMerchant.getingredientPrice() << " Gold? (y/n)" << endl;
                cin >> yeno;
                if(yeno =='y'){
                    while(gold <= num * myMerchant.getingredientPrice()){
                        cout << "You don't have enough money for that. \nIs there another amount you would like (enter 0 to quit)?" << endl;
                        cin >> num;
                    }
                    if(num > 0){
                        ingredients += num;
                        gold -= (num * myMerchant.getingredientPrice());
                        cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                        num = 0;
                    }
                }if(yeno == 'n'){
                    num = 0;
                }
            }
            cout << endl;
            menu = 0;
            break;
        case 2:
            cout << "I have a several types of cookware, which one would you like?\nEach type has a different probability of breaking when used, marked with (XX%).\n" << endl;
            cout << "\nChoose one of the following:\n1. (25%) Ceramic Pot ["<< myMerchant.getPotPrice() <<" Gold]\n2. (10%) Frying Pan ["<< myMerchant.getPanPrice() <<" Gold]\n3. ( 2%) Cauldron ["<< myMerchant.getCauldronPrice() <<" Gold]\n4. Cancel" << endl;
            cin >> choice;
            if(choice != 4){
            cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num; }
            if(num > 0){
                switch(choice){
                    case 1:
                        cout << "You want to buy " << num << " Ceramic Pot(s) for " << num * myMerchant.getPotPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(gold <= num * myMerchant.getPotPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                pots += num;
                                gold-= (num*myMerchant.getPotPrice());
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 2:
                        cout << "You want to buy " << num << " Frying Pan(s) for " << num * myMerchant.getPanPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(gold <= num * myMerchant.getPanPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                pans += num;
                                gold -= (num*myMerchant.getPanPrice());
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 3:
                        cout << "You want to buy " << num << " Cauldron(s) for " << num * myMerchant.getCauldronPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(gold <= num * myMerchant.getCauldronPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                cauldrons += num;
                                gold -=-(num*myMerchant.getCauldronPrice());
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 4:
                        break;
                    default:
                    cout << "That was not a valid input, back to the menu!" << endl;
                }
            }
            menu = 0;
            break;
        case 3:
            cout << "I have a plentiful collection of weapons to choose from, what would you like? \nNote that some of them provide you a special bonus in combat, marked by a (+X).\n" << endl;
            cout << "1. Stone Club ["<< myMerchant.getClubPrice() << " Gold] \n2. Iron Spear [" << myMerchant.getSpearPrice() << " Gold] \n3. (+1) Mythril Rapier [" << myMerchant.getRapierPrice() << " Gold] \n4. (+2) Flaming Battle-Axe [" << myMerchant.getAxePrice() << " Gold]\n5. (+3) Vorpal Longsword [" << myMerchant.getLongswordPrice() << " Gold]\n6. Cancel" << endl;
            cin >> choice;
            if(choice != 6){
            cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num; }
            if(num > 0){
                switch(choice){
                    case 1: 
                        cout << "You want to buy " << num << " Stone Club(s) for " << num * myMerchant.getClubPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(gold <= num * myMerchant.getClubPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                clubs += num;
                                gold -= (num*myMerchant.getClubPrice());
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; }
                        break;
                    case 2:
                         cout << "You want to buy " << num << " Iron Spear(s) for " << num * myMerchant.getSpearPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(gold <= num * myMerchant.getSpearPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                spears += num;
                                gold -= (num*myMerchant.getSpearPrice());
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0;    }
                        break;
                    case 3:
                        cout << "You want to buy " << num << " (+1) Mythril Rapier(s) for " << num * myMerchant.getRapierPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(gold <= num * myMerchant.getRapierPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                rapier += num;
                                gold -= (num * myMerchant.getRapierPrice());
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0;    }
                        break;
                    case 4:
                        cout << "You want to buy " << num << " (+2) Flaming Battle-Axe(s) for " << num * myMerchant.getAxePrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(gold <= num * myMerchant.getAxePrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                axes += num;
                                gold -= (num * myMerchant.getAxePrice());
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                            num = 0;    }
                        break;
                    case 5:
                         cout << "You want to buy " << num << " (+3) Vorpal Longsword(s) for " << num * myMerchant.getLongswordPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if( gold <= num * myMerchant.getLongswordPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                longsword += num;
                                gold -= (num * myMerchant.getLongswordPrice());
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                            num = 0;    }
                        break;
                    case 6: 
                        break;
                    default:
                        cout << "That was not a valid input, back to the menu!" << endl;
                }
            }
            cout << endl;
            menu = 0;
            break;
        case 4:
            cout << "Armor protects you from monsters. Equipping your team with the maximum amount of armor (1 armor per person) will maximize your chances of survival during an attack. \nAdding more armor on top of the maximum amount will not increase your chances further." << endl;
            cout << "How many suits of armor can I get you? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num;
            if(num < 0){
                cout << "Invalid input." << endl;
                menu = 2;
                break; }    
            while(num != 0){
                cout << "You want to buy " << num << " suit(s) of armor for "<< num * myMerchant.getArmorPrice() << " Gold? (y/n)" << endl;
                cin >> yeno;
                if(yeno =='y'){
                    while(gold <= num * myMerchant.getArmorPrice()){
                        cout << "You don't have enough money for that. \nIs there another amount you would like (enter 0 to quit)?" << endl;
                        cin >> num;
                    }
                    if(num > 0){
                        armor += num;
                        gold -= (num * myMerchant.getArmorPrice());
                        cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                        num = 0;
                    }
                }if(yeno == 'n'){
                    num = 0;
                }
            }
            menu = 0;
            break;
        case 5: 
            cout << "What treasures would you like to sell me?\nCheck your invintory, it looks like you have:" << endl;
            if(rings > 0){
                cout << "Silver ring (R) - 10 gold pieces each" << endl;
            }
            if(necklaces > 0){
                cout << "Ruby necklace (N) - 20 gold pieces each" << endl;
            }
            if(bracelets > 0){
                cout << "Emerald bracelet (B) - 30 gold pieces each" << endl;
            }
            if(circlets > 0){
                cout << "Diamond circlet (C) - 40 gold pieces each" << endl;
            }
            if(goblets > 0){
                cout << "Gem-encrusted goblet (G) - 50 gold pieces each" << endl;
            }
            cout << "\nEnter the key displayed above (if any) to sell me you treasure (enter case sensitive letter from display)\nIf you don't see anything come back after you have cleared a few levels!" << endl;
            cin >> treasure;
            cout << "How many are you willing to share? (positive integer or zero to quit" << endl;
            cin >> num;
            if(num > 0){
                switch(treasure){
                case 'R':
                    if(rings >= num){
                        rings -= num;
                        gold += (num * 10);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'N':
                    if(necklaces >= num){
                        necklaces -= num;
                        gold += (num * 20);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'B':
                    if(bracelets >= num){
                        bracelets -= num;
                        gold += (num * 30);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'C':
                    if(circlets >= num){
                        circlets -= num;
                        gold +=(num * 40);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'G':
                    if(goblets >= num){
                        goblets - num;
                        gold +=(num * 50);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                default:
                    cout << "That's an invalid input silly goose no treasure for you!" << endl;
                }
            }
            menu = 0;
            break;
        case 6: 
            cout << "Are you sure you're finished? You won't be able to buy anything else from me! (y/n)" << endl;
            cin >> yeno;
            if(yeno == 'n'){
                menu = 0;
                break;
            }
        } 
    }
}

void Status :: randomMis(int first){
    int second;
    switch(first){
        case 0: case 1: case 2:
            cout << "OH NO! Your team was robbed by dungeon bandits!" << endl;
            ingredients -= 10;
            second = rand() % 3;
                switch(second){
                case 0:
                    if(cauldrons > 0){
                    cout << "You lost 1 cauldron!" << endl;
                    cauldrons--;
                    break;
                    }
                case 1:
                    if(pots > 0){
                    cout << "You lost 1 pot!" << endl;
                    pots--;
                    break;
                    }
                case 2: 
                    if(pans > 0){
                    cout << "You lost 1 pan!" << endl;
                    pans--;
                    break;
                    }
                default:
                    if(armor > 0){
                    armor--;
                    cout << "You lost 1 armor" << endl;
                    }
                    break;
                }
            break;
        case 3:
            second = rand() % 5;
            switch(second){
            case 0:
                if(clubs > 0){
                cout << "OH NO! Your Club broke!" << endl;
                clubs--;
                break;
                }
            case 1:
                if(rapier > 0){
                cout << "OH NO! Your +1 Rapier broke!" << endl;
                rapier--;
                break;
                }
            case 2: 
                if(spears > 0){
                cout << "OH NO! Your Spear broke!" << endl;
                spears--;
                break;
                }
            case 3:
                if(longsword > 0){
                cout << "OH NO! Your +3 Longsword broke!" << endl;
                longsword--;
                break;
                }
            case 4: 
                if(axes > 0){
                cout << "OH NO! Your +2 Axe broke!" << endl;
                axes--;
                break;
                }
            default:
                if(armor > 0){
                    armor--;
                    cout << "You lost 1 armor" << endl;
                }
                break;
            }
            break;
        case 4: case 5: case 6:
            party.at(first).lose_fullness(10);
            cout << party.at(first).getplayername() << " lost 10 hunger." << endl;
            if(party.at(first).getfullness() == 0){
                cout << party.at(first).getplayername() << " has died! continue on without them." << endl;
                party.erase(party.begin() + first);
            }
            break;
        default: 
            break;
    }   
}