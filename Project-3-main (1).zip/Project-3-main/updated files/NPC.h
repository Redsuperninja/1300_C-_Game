//NPC.h

// CSCI 1300 Spring 2023
// Author: Mallory Phillips Tawhid Ather
// Recitation: 104 – Tuhina Tripathi
// Project 3 

#ifndef NPC_H
#define NPC_H
#include <iostream>
#include <vector>

using namespace std;

struct riddle
{
    string body;
    string answer;
};

class NPC
{
    private:
    //price value for every item sold by the merchant
    int ingredient_price;
    int pot_price;
    int pan_price;
    int cauldron_price;
    int club_price;
    int spear_price;
    int axe_price;
    int rapier_price;
    int longsword_price;
    int armor_price;
    vector <riddle> myRiddles;
    vector <string> NPC_dialogue;
    
    public:
    void loadDialogue(string);
    void loadRidddles(string);
    NPC();  //default constructor
    NPC(int); //constructor with string, file name that will referance a text file for dialogue
    string getDialogue(int);
    bool getRiddle(int);
    int getingredientPrice();
    int getPotPrice();
    int getPanPrice();
    int getCauldronPrice();
    int getClubPrice();
    int getSpearPrice();
    int getAxePrice();
    int getRapierPrice();
    int getLongswordPrice();
    int getArmorPrice();
};

#endif