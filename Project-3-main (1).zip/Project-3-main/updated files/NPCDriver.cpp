//NPC.cpp

// CSCI 1300 Spring 2023
// Author: Mallory Phillips
// Recitation: 104 – Tuhina Tripathi
// Project 3


#include <iostream>
#include <string>
#include <fstream>
#include <cassert>
#include "NPC.h"
#include "Status.h"

using namespace std;

int main(){
    srand((unsigned int)time(0));
    //creates default object
    NPC npc;
    assert(npc.getingredientPrice() == 1);
    assert(npc.getPotPrice() == 5);
    assert(npc.getPanPrice() == 10);
    assert(npc.getCauldronPrice() == 20);
    assert(npc.getClubPrice() == 2);
    assert(npc.getSpearPrice() == 2);
    assert(npc.getAxePrice() == 15);
    assert(npc.getRapierPrice() == 5);
    assert(npc.getLongswordPrice() == 50);
    assert(npc.getArmorPrice() == 5);
    //will test void  function when incrimented properly with other functions
    //vector funciton in parameterized funciotn will be tested wiht developted tedt files

    int menu = 0;
    int choice = 0;
    int num = 0;
    char yeno;
    char treasure;

    NPC myMerchant(4);
    Status myStatus;
    myMerchant.loadDialogue("npcDialogue.txt");
    cout << myMerchant.getDialogue(25)<< endl;
    myMerchant.loadRidddles("riddles.txt");
    cout << myMerchant.getRiddle(25) << endl;


   /*
    cout << "Between the 5 of you, you have 100 gold pieces. \nYou will need to spend the some of your money on the following items:\n" << endl;
    cout << " - INGREDIENTS. To make food, you have to cook raw ingredients." << endl;
    cout << " - COOKWARE. If you want to cook, you have to have cookware first." << endl;
    cout << " - WEAPONS. You'll want at least one weapon per party member to fend off monsters." << endl;
    cout<< " - ARMOR. Armor increases the chances of surviving a monster attack.\n" << endl;
    cout<< "You can spend all of your money here before you start your journey, or you can save some to spend on merchants along the way. But beware, some of the merchants in this dungeon are shady characters, and they won't always give you a fair price..." << endl;

    while(menu != 6){
        while(menu < 1 || menu > 6){
            cout << "\n+-------------+\n| INVENTORY   |\n+-------------+\n| Gold        | " << myStatus.getGold() << "\n| Ingredients | " <<myStatus.getIngredients() << " kg \n| Cookware    | P: " << myStatus.getPot() << " | F: " << myStatus.getPan() << " | C: " << myStatus.getCauldron() << endl;
            cout << "| Weapons     | C: " << myStatus.getClub() << " | S: " << myStatus.getSpear() << " | R: " << myStatus.getRapier() << " | B: " << myStatus.getAxe() << " | L: " << myStatus.getLongsword() << "\n| Armor       | " << myStatus.getArmor() << "\n| Treasures   | R: " << myStatus.getRings() << " | N: " << myStatus.getNecklaces() << " | B: " << myStatus.getBracelets() << " | C: " << myStatus.getCirclets() << " | G: " << myStatus.getGoblets() << "" << endl;
            cout <<"\nChoose one of the following: \n1. Ingredients: To make food, you have to cook raw ingredients. \n2. Cookware: You will need something to cook those ingredients. \n3. Weapons: It's dangerous to go alone, take this!" << endl;
            cout << "4. Armor: If you want to survive monster attacks, you will need some armor. \n5. Sell treasures: If you find anything shiny, I would be happy to take it off your hands. \n6. Leave: Make sure you get everything you need, I'm leaving after this sale!" << endl;
            cin >> menu;
            if(menu < 1 || menu > 6){
                cout << "Invalid input. Please enter a number between 1 and 6." << endl;
                menu = 0; }
            cout << endl;
        }
    switch(menu){
        case 1: 
            cout << "I would recomend 10 kg of food per party member for your voyage!" << endl;
            cout << "How many kg of ingredients do you need [" << myMerchant.getingredientPrice() << " Gold/kg]? (Enter a positive mulitple of 5, or 0 to cancel)" << endl;
            cin >> num;
            if(num % 5 != 0){
                cout << "Invalid input." << endl;
                menu = 1;
                break; }    
            while(num != 0){
                cout << "You want to buy " << num << " kg of ingredients for "<< num * myMerchant.getingredientPrice() << " Gold? (y/n)" << endl;
                cin >> yeno;
                if(yeno =='y'){
                    while(myStatus.getGold() <= num * myMerchant.getingredientPrice()){
                        cout << "You don't have enough money for that. \nIs there another amount you would like (enter 0 to quit)?" << endl;
                        cin >> num;
                    }
                    if(num > 0){
                        myStatus.incrementIngredients(num);
                        myStatus.incrementGold(-1*(num * myMerchant.getingredientPrice()));
                        cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                        num = 0;
                    }
                }if(yeno == 'n'){
                    num = 0;
                }
            }
            cout << endl;
            menu = 0;
            break;
        case 2:
            cout << "I have a several types of cookware, which one would you like?\nEach type has a different probability of breaking when used, marked with (XX%).\n" << endl;
            cout << "\nChoose one of the following:\n1. (25%) Ceramic Pot ["<< myMerchant.getPotPrice() <<" Gold]\n2. (10%) Frying Pan ["<< myMerchant.getPanPrice() <<" Gold]\n3. ( 2%) Cauldron ["<< myMerchant.getCauldronPrice() <<" Gold]\n4. Cancel" << endl;
            cin >> choice;
            if(choice != 4){
            cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num; }
            if(num > 0){
                switch(choice){
                    case 1:
                        cout << "You want to buy " << num << " Ceramic Pot(s) for " << num * myMerchant.getPotPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getPotPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                for(int i = 0; i < num; i++){
                                    myStatus.incrementPot();
                                }
                                myStatus.incrementGold(-1*(num*myMerchant.getPotPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 2:
                        cout << "You want to buy " << num << " Frying Pan(s) for " << num * myMerchant.getPanPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getPanPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                for(int i = 0; i < num; i++){
                                    myStatus.incrementPan();
                                }
                                myStatus.incrementGold(-1*(num*myMerchant.getPanPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 3:
                        cout << "You want to buy " << num << " Cauldron(s) for " << num * myMerchant.getCauldronPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getCauldronPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                for(int i = 0; i < num; i++){
                                    myStatus.incrementCauldron();
                                }
                                myStatus.incrementGold(-1*(num*myMerchant.getCauldronPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 4:
                        break;
                    default:
                    cout << "That was not a valid input, back to the menu!" << endl;
                }
            }
            menu = 0;
            break;
        case 3:
            cout << "I have a plentiful collection of weapons to choose from, what would you like? \nNote that some of them provide you a special bonus in combat, marked by a (+X).\n" << endl;
            cout << "1. Stone Club ["<< myMerchant.getClubPrice() << " Gold] \n2. Iron Spear [" << myMerchant.getSpearPrice() << " Gold] \n3. (+1) Mythril Rapier [" << myMerchant.getRapierPrice() << " Gold] \n4. (+2) Flaming Battle-Axe [" << myMerchant.getAxePrice() << " Gold]\n5. (+3) Vorpal Longsword [" << myMerchant.getLongswordPrice() << " Gold]\n6. Cancel" << endl;
            cin >> choice;
            if(choice != 6){
            cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num; }
            if(num > 0){
                switch(choice){
                    case 1: 
                        cout << "You want to buy " << num << " Stone Club(s) for " << num * myMerchant.getClubPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getClubPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementClub(num);
                                myStatus.incrementGold(-1*(num*myMerchant.getClubPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; }
                        break;
                    case 2:
                         cout << "You want to buy " << num << " Iron Spear(s) for " << num * myMerchant.getSpearPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getSpearPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementSpears(num);
                                myStatus.incrementGold(-1*(num*myMerchant.getSpearPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0;    }
                        break;
                    case 3:
                        cout << "You want to buy " << num << " (+1) Mythril Rapier(s) for " << num * myMerchant.getRapierPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getRapierPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementRapier(num);
                                myStatus.incrementGold(-1*(num * myMerchant.getRapierPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0;    }
                        break;
                    case 4:
                        cout << "You want to buy " << num << " (+2) Flaming Battle-Axe(s) for " << num * myMerchant.getAxePrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getAxePrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementAxe(num);
                                myStatus.incrementGold(-1*(num * myMerchant.getAxePrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                            num = 0;    }
                        break;
                    case 5:
                         cout << "You want to buy " << num << " (+3) Vorpal Longsword(s) for " << num * myMerchant.getLongswordPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getLongswordPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementLongsword(num);
                                myStatus.incrementGold(-1*(num * myMerchant.getLongswordPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                            num = 0;    }
                        break;
                    case 6: 
                        break;
                    default:
                        cout << "That was not a valid input, back to the menu!" << endl;
                }
            }
            cout << endl;
            menu = 0;
            break;
        case 4:
            cout << "Armor protects you from monsters. Equipping your team with the maximum amount of armor (1 armor per person) will maximize your chances of survival during an attack. \nAdding more armor on top of the maximum amount will not increase your chances further." << endl;
            cout << "How many suits of armor can I get you? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num;
            if(num < 0){
                cout << "Invalid input." << endl;
                menu = 2;
                break; }    
            while(num != 0){
                cout << "You want to buy " << num << " suit(s) of armor for "<< num * myMerchant.getArmorPrice() << " Gold? (y/n)" << endl;
                cin >> yeno;
                if(yeno =='y'){
                    while(myStatus.getGold() <= num * myMerchant.getArmorPrice()){
                        cout << "You don't have enough money for that. \nIs there another amount you would like (enter 0 to quit)?" << endl;
                        cin >> num;
                    }
                    if(num > 0){
                        myStatus.incrementArmor(num);
                        myStatus.incrementGold(-1*(num * myMerchant.getArmorPrice()));
                        cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                        num = 0;
                    }
                }if(yeno == 'n'){
                    num = 0;
                }
            }
            menu = 0;
            break;
        case 5: 
            cout << "What treasures would you like to sell me?\nCheck your invintory, it looks like you have:" << endl;
            if(myStatus.getRings() > 0){
                cout << "Silver ring (R) - 10 gold pieces each" << endl;
            }
            if(myStatus.getNecklaces() > 0){
                cout << "Ruby necklace (N) - 20 gold pieces each" << endl;
            }
            if(myStatus.getBracelets() > 0){
                cout << "Emerald bracelet (B) - 30 gold pieces each" << endl;
            }
            if(myStatus.getCirclets() > 0){
                cout << "Diamond circlet (C) - 40 gold pieces each" << endl;
            }
            if(myStatus.getGoblets() > 0){
                cout << "Gem-encrusted goblet (G) - 50 gold pieces each" << endl;
            }
            cout << "\nEnter the key displayed above (if any) to sell me you treasure (enter case sensitive letter from display)\nIf you don't see anything come back after you have cleared a few levels!" << endl;
            cin >> treasure;
            cout << "How many are you willing to share? (positive integer or zero to quit" << endl;
            cin >> num;
            if(num > 0){
                switch(treasure){
                case 'R':
                    if(myStatus.getRings() >= num){
                        myStatus.setRings(myStatus.getRings() - num);
                        myStatus.incrementGold(num * 10);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'N':
                    if(myStatus.getNecklaces() >= num){
                        myStatus.setNecklaces(myStatus.getNecklaces() - num);
                        myStatus.incrementGold(num * 20);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'B':
                    if(myStatus.getBracelets() >= num){
                        myStatus.setBracelets(myStatus.getBracelets() - num);
                        myStatus.incrementGold(num * 30);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'C':
                    if(myStatus.getCirclets() >= num){
                        myStatus.setCirclets(myStatus.getCirclets() - num);
                        myStatus.incrementGold(num * 40);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'G':
                    if(myStatus.getGoblets() >= num){
                        myStatus.setGoblets(myStatus.getGoblets() - num);
                        myStatus.incrementGold(num * 50);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                default:
                    cout << "That's an invalid input silly goose no treasure for you!" << endl;
                }
            }
            menu = 0;
            break;
        case 6: 
            cout << "Are you sure you're finished? You won't be able to buy anything else from me! (y/n)" << endl;
            cin >> yeno;
            if(yeno == 'n'){
                menu = 0;
                break;
            }
    }
        
    }
    */

    return 0;
}