#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include<cstdlib>
#include<ctime>
#include<cmath>

#include "Map.h"
#include "monsters.h"
#include "status.h"
#include "players.h"
#include "NPC.h"

using namespace std;



void merchantMenu(Status myStatus, NPC myMerchant)
{
    int menu = 0;
    int choice = 0;
    int num = 0;
    char yeno;
    char treasure;


    while(menu != 6){
        while(menu < 1 || menu > 6){
            cout << "\n+-------------+\n| INVENTORY   |\n+-------------+\n| Gold        | " << myStatus.getGold() << "\n| Ingredients | " <<myStatus.getIngredients() << " kg \n| Cookware    | P: " << myStatus.getPot() << " | F: " << myStatus.getPan() << " | C: " << myStatus.getCauldron() << endl;
            cout << "| Weapons     | C: " << myStatus.getClub() << " | S: " << myStatus.getSpear() << " | R: " << myStatus.getRapier() << " | B: " << myStatus.getAxe() << " | L: " << myStatus.getLongsword() << "\n| Armor       | " << myStatus.getArmor() << "\n| Treasures   | R: " << myStatus.getRings() << " | N: " << myStatus.getNecklaces() << " | B: " << myStatus.getBracelets() << " | C: " << myStatus.getCirclets() << " | G: " << myStatus.getGoblets() << "" << endl;
            cout <<"\nChoose one of the following: \n1. Ingredients: To make food, you have to cook raw ingredients. \n2. Cookware: You will need something to cook those ingredients. \n3. Weapons: It's dangerous to go alone, take this!" << endl;
            cout << "4. Armor: If you want to survive monster attacks, you will need some armor. \n5. Sell treasures: If you find anything shiny, I would be happy to take it off your hands. \n6. Leave: Make sure you get everything you need, I'm leaving after this sale!" << endl;
            cin >> menu;
            if(menu < 1 || menu > 6){
                cout << "Invalid input. Please enter a number between 1 and 6." << endl;
                menu = 0; }
            cout << endl;
        }
        switch(menu){
        case 1: 
            cout << "I would recomend 10 kg of food per party member for your voyage!" << endl;
            cout << "How many kg of ingredients do you need [" << myMerchant.getingredientPrice() << " Gold/kg]? (Enter a positive mulitple of 5, or 0 to cancel)" << endl;
            cin >> num;
            if(num % 5 != 0){
                cout << "Invalid input." << endl;
                menu = 1;
                break; }    
            while(num != 0){
                cout << "You want to buy " << num << " kg of ingredients for "<< num * myMerchant.getingredientPrice() << " Gold? (y/n)" << endl;
                cin >> yeno;
                if(yeno =='y'){
                    while(myStatus.getGold() <= num * myMerchant.getingredientPrice()){
                        cout << "You don't have enough money for that. \nIs there another amount you would like (enter 0 to quit)?" << endl;
                        cin >> num;
                    }
                    if(num > 0){
                        myStatus.incrementIngredients(num);
                        myStatus.incrementGold(-1*(num * myMerchant.getingredientPrice()));
                        cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                        num = 0;
                    }
                }if(yeno == 'n'){
                    num = 0;
                }
            }
            cout << endl;
            menu = 0;
            break;
        case 2:
            cout << "I have a several types of cookware, which one would you like?\nEach type has a different probability of breaking when used, marked with (XX%).\n" << endl;
            cout << "\nChoose one of the following:\n1. (25%) Ceramic Pot ["<< myMerchant.getPotPrice() <<" Gold]\n2. (10%) Frying Pan ["<< myMerchant.getPanPrice() <<" Gold]\n3. ( 2%) Cauldron ["<< myMerchant.getCauldronPrice() <<" Gold]\n4. Cancel" << endl;
            cin >> choice;
            if(choice != 4){
            cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num; }
            if(num > 0){
                switch(choice){
                    case 1:
                        cout << "You want to buy " << num << " Ceramic Pot(s) for " << num * myMerchant.getPotPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getPotPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                for(int i = 0; i < num; i++){
                                    myStatus.incrementPot();
                                }
                                myStatus.incrementGold(-1*(num*myMerchant.getPotPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 2:
                        cout << "You want to buy " << num << " Frying Pan(s) for " << num * myMerchant.getPanPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getPanPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                for(int i = 0; i < num; i++){
                                    myStatus.incrementPan();
                                }
                                myStatus.incrementGold(-1*(num*myMerchant.getPanPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 3:
                        cout << "You want to buy " << num << " Cauldron(s) for " << num * myMerchant.getCauldronPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getCauldronPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                for(int i = 0; i < num; i++){
                                    myStatus.incrementCauldron();
                                }
                                myStatus.incrementGold(-1*(num*myMerchant.getCauldronPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; 
                        }
                        break;
                    case 4:
                        break;
                    default:
                    cout << "That was not a valid input, back to the menu!" << endl;
                }
            }
            menu = 0;
            break;
        case 3:
            cout << "I have a plentiful collection of weapons to choose from, what would you like? \nNote that some of them provide you a special bonus in combat, marked by a (+X).\n" << endl;
            cout << "1. Stone Club ["<< myMerchant.getClubPrice() << " Gold] \n2. Iron Spear [" << myMerchant.getSpearPrice() << " Gold] \n3. (+1) Mythril Rapier [" << myMerchant.getRapierPrice() << " Gold] \n4. (+2) Flaming Battle-Axe [" << myMerchant.getAxePrice() << " Gold]\n5. (+3) Vorpal Longsword [" << myMerchant.getLongswordPrice() << " Gold]\n6. Cancel" << endl;
            cin >> choice;
            if(choice != 6){
            cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num; }
            if(num > 0){
                switch(choice){
                    case 1: 
                        cout << "You want to buy " << num << " Stone Club(s) for " << num * myMerchant.getClubPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getClubPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementClub(num);
                                myStatus.incrementGold(-1*(num*myMerchant.getClubPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0; }
                        break;
                    case 2:
                         cout << "You want to buy " << num << " Iron Spear(s) for " << num * myMerchant.getSpearPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getSpearPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementSpears(num);
                                myStatus.incrementGold(-1*(num*myMerchant.getSpearPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0;    }
                        break;
                    case 3:
                        cout << "You want to buy " << num << " (+1) Mythril Rapier(s) for " << num * myMerchant.getRapierPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getRapierPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementRapier(num);
                                myStatus.incrementGold(-1*(num * myMerchant.getRapierPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                        num = 0;    }
                        break;
                    case 4:
                        cout << "You want to buy " << num << " (+2) Flaming Battle-Axe(s) for " << num * myMerchant.getAxePrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getAxePrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementAxe(num);
                                myStatus.incrementGold(-1*(num * myMerchant.getAxePrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                            num = 0;    }
                        break;
                    case 5:
                         cout << "You want to buy " << num << " (+3) Vorpal Longsword(s) for " << num * myMerchant.getLongswordPrice()<<" gold? (y/n)" << endl;
                        cin >> yeno;
                        if(yeno =='y'){
                            if(myStatus.getGold() <= num * myMerchant.getLongswordPrice()){
                                cout << "You don't have enough money for that. Broke a**!" << endl;
                                break;
                            }else{
                                myStatus.incrementLongsword(num);
                                myStatus.incrementGold(-1*(num * myMerchant.getLongswordPrice()));
                                cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                            }  
                        }else{
                            num = 0;    }
                        break;
                    case 6: 
                        break;
                    default:
                        cout << "That was not a valid input, back to the menu!" << endl;
                }
            }
            cout << endl;
            menu = 0;
            break;
        case 4:
            cout << "Armor protects you from monsters. Equipping your team with the maximum amount of armor (1 armor per person) will maximize your chances of survival during an attack. \nAdding more armor on top of the maximum amount will not increase your chances further." << endl;
            cout << "How many suits of armor can I get you? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num;
            if(num < 0){
                cout << "Invalid input." << endl;
                menu = 2;
                break; }    
            while(num != 0){
                cout << "You want to buy " << num << " suit(s) of armor for "<< num * myMerchant.getArmorPrice() << " Gold? (y/n)" << endl;
                cin >> yeno;
                if(yeno =='y'){
                    while(myStatus.getGold() <= num * myMerchant.getArmorPrice()){
                        cout << "You don't have enough money for that. \nIs there another amount you would like (enter 0 to quit)?" << endl;
                        cin >> num;
                    }
                    if(num > 0){
                        myStatus.incrementArmor(num);
                        myStatus.incrementGold(-1*(num * myMerchant.getArmorPrice()));
                        cout << "\nThank you for your patronage! What else can I get for you?" << endl;
                        num = 0;
                    }
                }if(yeno == 'n'){
                    num = 0;
                }
            }
            menu = 0;
            break;
        case 5: 
            cout << "What treasures would you like to sell me?\nCheck your invintory, it looks like you have:" << endl;
            if(myStatus.getRings() > 0){
                cout << "Silver ring (R) - 10 gold pieces each" << endl;
            }
            if(myStatus.getNecklaces() > 0){
                cout << "Ruby necklace (N) - 20 gold pieces each" << endl;
            }
            if(myStatus.getBracelets() > 0){
                cout << "Emerald bracelet (B) - 30 gold pieces each" << endl;
            }
            if(myStatus.getCirclets() > 0){
                cout << "Diamond circlet (C) - 40 gold pieces each" << endl;
            }
            if(myStatus.getGoblets() > 0){
                cout << "Gem-encrusted goblet (G) - 50 gold pieces each" << endl;
            }
            cout << "\nEnter the key displayed above (if any) to sell me you treasure (enter case sensitive letter from display)\nIf you don't see anything come back after you have cleared a few levels!" << endl;
            cin >> treasure;
            cout << "How many are you willing to share? (positive integer or zero to quit" << endl;
            cin >> num;
            if(num > 0){
                switch(treasure){
                case 'R':
                    if(myStatus.getRings() >= num){
                        myStatus.setRings(myStatus.getRings() - num);
                        myStatus.incrementGold(num * 10);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'N':
                    if(myStatus.getNecklaces() >= num){
                        myStatus.setNecklaces(myStatus.getNecklaces() - num);
                        myStatus.incrementGold(num * 20);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'B':
                    if(myStatus.getBracelets() >= num){
                        myStatus.setBracelets(myStatus.getBracelets() - num);
                        myStatus.incrementGold(num * 30);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'C':
                    if(myStatus.getCirclets() >= num){
                        myStatus.setCirclets(myStatus.getCirclets() - num);
                        myStatus.incrementGold(num * 40);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                case 'G':
                    if(myStatus.getGoblets() >= num){
                        myStatus.setGoblets(myStatus.getGoblets() - num);
                        myStatus.incrementGold(num * 50);
                    }else{
                        cout << "You dont have enough to sell silly!" << endl;
                    }
                    num = 0;
                    break;
                default:
                    cout << "That's an invalid input silly goose no treasure for you!" << endl;
                }
            }
            menu = 0;
            break;
        case 6: 
            cout << "Are you sure you're finished? You won't be able to buy anything else from me! (y/n)" << endl;
            cin >> yeno;
            if(yeno == 'n'){
                menu = 0;
                break;
            }
        } 
    }
}

bool rps(){
    cout << "Let's play Boulder/Parchment/Shears! If you loose three times you'll loose a party member." << endl;
    bool end_game = 0;
    bool win_lose;  // 1 means player wins 0 means computer won
    int user;
    int computer;
    int game_count;
    while(!end_game)
    {
        game_count ++;
        computer = (rand()%3);
        cout << "Enter: \n(1) Boulder \n(2) Parchment \n(3) Shears" << endl;
        cin >> user;
        if(user == computer){
            cout << "tie!" << endl;
            continue;
        }
        if(computer == 1 && user == 2){
           win_lose = 1;
           end_game = true;
           cout << "Congrats!!" << endl;
           continue;
        }else if(computer == 2 && user == 3){
           win_lose = 1;
           end_game = true;
           cout << "Congrats!!" << endl;
           continue;
        }else if(computer == 3 && user == 1){
           win_lose = 1;
           end_game = true;
           cout << "Congrats!!" << endl;
           continue;
        }
        cout << "you lose!" << endl;
        if(game_count == 3){
            //kill a player
            cout << "You lost a playe to the door, beware and find a key!" << endl;
            end_game = true;
        }
    }
   return win_lose;
}

int main() {
    //setting random number generator to be used for probability
    srand((unsigned int)time(0));
    Status status;
    Map map;
    Monsters monsters(1);
    NPC riddler;
    riddler.loadRidddles("riddles.txt");
    string monster_name;
    int action_choice = 0;
    char player_move = ' ';
    bool game_over = false;
    bool game_win = false;
    bool myKey = false;


    map.setPlayerPosition((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    map.setDungeonExit((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    //set rooms
    while(map.getRoomCount() != 5) {
        map.addRoom((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    }
    while(map.getNPCCount() != 5) {
        map.addNPC((double(rand() / double(RAND_MAX)) * 12), ((double(rand() / double(RAND_MAX)) * 12)));
    }
    status.setpartymembers();
    //prompt user in shop before start of the game
    cout << "Between the 5 of you, you have 100 gold pieces. \nYou will need to spend the some of your money on the following items:\n" << endl;
    cout << " - INGREDIENTS. To make food, you have to cook raw ingredients." << endl;
    cout << " - COOKWARE. If you want to cook, you have to have cookware first." << endl;
    cout << " - WEAPONS. You'll want at least one weapon per party member to fend off monsters." << endl;
    cout<< " - ARMOR. Armor increases the chances of surviving a monster attack.\n" << endl;
    cout<< "You can spend all of your money here before you start your journey, or you can save some to spend on merchants along the way. But beware, some of the merchants in this dungeon are shady characters, and they won't always give you a fair price..." << endl;
    merchantMenu(status,riddler);
    while (!game_over || !game_win) {

        status.printstatus();

        map.displayMap();
        //if the player is on the dungeon exit
        if (map.isDungeonExit(map.getPlayerRow(), map.getPlayerCol())) {
            if(map.getRoomCount() == 0) {
                cout << "You have vanquished the sorcerer and reach the exit!" << endl;
                game_win = true;
            }
            else{
                cout << "You can't exit the dungeon yet! Continue to explore the duegon and vanish the sorcer to unlock the exit." << endl;
                cout << "Select a direction to move" << endl;
                cin >> player_move;
                while(map.move(player_move) == false) {
                    cout << "Please enter a valid direction" << endl;
                    cin >> player_move;
                }
            }
        }
        //if the player has entered a room
        else if(map.isRoomLocation(map.getPlayerRow(), map.getPlayerCol())) {
            cout << "You have entered the room! What would you like to do?" << endl;
            cout <<  "Select one:" << endl;
            cout << "1. Move" << endl;
            cout << "2. Open the Door"  << endl;
            cout << "3. Give up" << endl;
            cin >> action_choice;
            switch(action_choice) {
                case 1:
                    cout << "Select a direction to move" << endl;
                    cin >> player_move;
                    while(map.move(player_move) == false) {
                        cout << "Please enter a valid direction" << endl;
                        cin >> player_move;
                    }
                    break;
                case 2:
                    if(rps()== 0){
                        //can exit room
                    }else{
                        //kill player
                    }
                    //returns to location on map
                    break;
                case 3:
                    cout << "The party has given up." << endl;
                    game_over = true;
                    break;
                default:
                    cout << "Please choose a valid action" << endl;
                    while(action_choice < 1 || action_choice > 3) {
                        cout <<  "Select one:" << endl;
                        cout << "1. Move" << endl;
                        cout << "2. Open the Door"  << endl;
                        cout << "3. Give up" << endl;
                        cin >> action_choice;
                    }
                    break;
            }
        }
        //if the player has meet an NPC
        else if(map.isNPCLocation(map.getPlayerRow(), map.getPlayerCol())) {
            NPC myNPC(status.getRoomsCleared());
            myNPC.loadDialogue("npcDialogue");
            myNPC.loadRidddles("riddles.txt");
            cout << "You have encounter an NPC! What would you like to do?" << endl;
            cout <<  "Select one:" << endl;
            cout << "1. Move" << endl;
            cout << "2. Speak to NPC"  << endl;
            cout << "3. Give up" << endl;
            cin >> action_choice;
            switch(action_choice) {
                case 1:
                    cout << "Select a direction to move" << endl;
                    cin >> player_move;
                    while(map.move(player_move) == false) {
                        cout << "Please enter a valid direction" << endl;
                        cin >> player_move;
                    }
                    break;
                case 2:
                    cout << myNPC.getDialogue(rand()) << endl;
                    map.removeNPC(map.getPlayerRow(), map.getPlayerCol());
                    cout << "Riddle me this and we can do business" << endl;
                    if(myNPC.getRiddle(rand())){
                        merchantMenu(status,myNPC);
                    }else{
                        cout << "Oh well maybe next time" << endl;
                    }
                    break;
                case 3:
                    cout << "The party has given up." << endl;
                    game_over = true;
                    break;
                default:
                    cout << "Please choose a valid action" << endl;
                    while(action_choice < 1 || action_choice > 3) {
                        cout <<  "Select one:" << endl;
                        cout << "1. Move" << endl;
                        cout << "2. Speak to NPC"  << endl;
                        cout << "3. Give up" << endl;
                        cin >> action_choice;
                    }
                    break;
            }
        }
        else { 
            cout <<  "Select one:" << endl;
            cout << "1. Move" << endl;
            cout << "2. Investigate"  << endl;
            cout << "3. Pick a Fight" << endl;
            cout << "4. Cook and Eat" << endl;
            cout << "5. Give up" << endl;
            cin >> action_choice;
            switch(action_choice) {
                case 1:
                    cout << "Select a direction to move" << endl;
                    cin >> player_move;
                    while(map.move(player_move) == false) {
                        cout << "Please enter a valid direction" << endl;
                        cin >> player_move;
                    }
                    break;
                case 2:
                    if(!map.isExplored(map.getPlayerRow(),map.getPlayerCol())){
                        int myRand = rand() % 10;
                        if(myRand == 1){
            
                        }
                        map.exploreSpace(map.getPlayerRow(),map.getPlayerCol());
                    }
                    break;
                case 3:
                    cout << "You decide to go looking for a fight. Lets see what you find." << endl;
                    monster_name = monsters.getmonster((double(rand() / double(RAND_MAX)) * monsters.get_number_of_monsters()));
                    cout << monster_name << "AHEAD! THEY LOOK HOSTILE!" << endl;
                    if(status.getnumberweapons() >= 1) {
                        cout << "Choose if you want to fight or surrender" << endl;
                        cout << "1. Attack" << endl;
                        cout << "2. Surrender"  << endl;
                        cin >> action_choice;
                    }
                    else{
                        cout << "You have no weapons you must surrender" << endl;
                    }
                    break;
                case 4:
                    break;
                case 5:
                    cout << "The party has given up." << endl;
                    game_over = true;
                    break;
                default:
                    cout << "Please choose a valid action" << endl;
                    while(action_choice < 1 || action_choice > 5) {
                        cout <<  "Select one:" << endl;
                        cout << "1. Move" << endl;
                        cout << "2. Investigate"  << endl;
                        cout << "3. Pick a Fight" << endl;
                        cout << "4. Cook and Eat" << endl;
                        cout << "5. Give up" << endl;
                        cin >> action_choice;
                    }  
                    break;
            }
        }
    }
    return 0;
}